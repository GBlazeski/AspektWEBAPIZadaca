﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;



namespace AspektWebAPIZadaca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly CountryContext _context;
        public CountryController(CountryContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<CountryTable>> GetCountries()
        {
            return _context.Countries.ToList();
        }
        [HttpGet("{id}")]
        public ActionResult<CountryTable> GetCountry(int id)
        {
            var Country = _context.Countries.Find(id);
            if (Country == null)
            {
                return NotFound();
            }
            return Country;
        }
        [HttpPost]
        public ActionResult<CountryTable> CreateCountry(CountryTable Country)
        {
            if (Country == null)
            {
                return BadRequest();
            }
            _context.Countries.Add(Country);
            _context.SaveChanges();
            return CreatedAtAction(nameof(CountryTable), new { id = Country.CountryId }, Country);
        }
    }

}
