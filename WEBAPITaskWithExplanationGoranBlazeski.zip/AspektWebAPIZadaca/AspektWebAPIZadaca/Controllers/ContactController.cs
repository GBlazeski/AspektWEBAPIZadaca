﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;



namespace AspektWebAPIZadaca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly ContactContext _context;
        public ContactController(ContactContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<ContactTable>> GetContacts()
        {
            return _context.Contacts.ToList();
        }
        [HttpGet("{id}")]
        public ActionResult<ContactTable> GetContact(int id)
        {
            var Contact = _context.Contacts.Find(id);
            if (Contact == null)
            {
                return NotFound();
            }
            return Contact;
        }
        
        [HttpPost]
        public ActionResult<ContactTable> CreateContact(ContactTable Contact)
        {
            if (Contact == null)
            {
                return BadRequest();
            }
            _context.Contacts.Add(Contact);
            _context.SaveChanges();
            return CreatedAtAction(nameof(ContactTable), new { id = Contact.ContactId }, Contact);
        }
    }

}
