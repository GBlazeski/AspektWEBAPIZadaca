﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;



namespace AspektWebAPIZadaca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly CompanyContext _context;
        public CompanyController(CompanyContext context)
        {
            _context = context;
        }
        
        [HttpGet]
        public ActionResult<IEnumerable<CompanyTable>> GetCompanies()
        {
            return _context.Companies.ToList();
        }
       
        [HttpGet("{id}")]
        public ActionResult<CompanyTable> GetCompany(int id)
        {
            var company = _context.Companies.Find(id);
            if (company == null)
            {
                return NotFound();
            }
            return company;
        }
        [HttpPost]
        public ActionResult<CompanyTable> CreateCompany(CompanyTable company)
        {
            if (company == null)
            {
                return BadRequest();
            }
            _context.Companies.Add(company);
            _context.SaveChanges();
            return CreatedAtAction(nameof(CompanyTable), new { id = company.CompanyId }, company);
        }
    }
   
}
