﻿using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;

public class CountryContext : DbContext
{
    public CountryContext(DbContextOptions options) : base(options) { }
   public  DbSet<CountryTable> Countries
    {
        get;
        set;
    }
}