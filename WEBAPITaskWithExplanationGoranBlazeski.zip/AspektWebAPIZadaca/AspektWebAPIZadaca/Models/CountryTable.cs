﻿using System.ComponentModel.DataAnnotations;

namespace AspektWebAPIZadaca.Models
{
    public class CountryTable
    {
        [Key]
        public int CountryId { get; set; } 
        public int CountryName {  get; set; }
    }
}
