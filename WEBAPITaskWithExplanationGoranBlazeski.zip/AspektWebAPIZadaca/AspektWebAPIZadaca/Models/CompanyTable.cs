﻿using System.ComponentModel.DataAnnotations;

namespace AspektWebAPIZadaca.Models
{
    public class CompanyTable
    {
        [Key]
        public int CompanyId { get; set; }
        public required string CompanyName { get; set; }
        public int GetCompany() { return CompanyId; }
    }
}
    