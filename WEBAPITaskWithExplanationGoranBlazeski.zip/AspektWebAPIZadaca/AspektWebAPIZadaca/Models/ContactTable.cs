﻿using System.ComponentModel.DataAnnotations;

namespace AspektWebAPIZadaca.Models
{
    public class ContactTable
    {
        [Key]
        public int ContactId { get; set; }
        public required string ContactName { get; set; }
        public int CompanyId { get; set; } 
        public int CountryId {  get; set; }
    }
}
