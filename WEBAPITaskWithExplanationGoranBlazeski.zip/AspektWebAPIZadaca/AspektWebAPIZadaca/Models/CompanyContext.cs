﻿using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;

public class CompanyContext: DbContext 
{
    public CompanyContext(DbContextOptions<CompanyContext> options) : base(options) { }
    public DbSet<CompanyTable> Companies
    {
        get;
        set;
    }
}