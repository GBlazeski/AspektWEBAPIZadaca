﻿using AspektWebAPIZadaca.Models;
using Microsoft.EntityFrameworkCore;

public class ContactContext : DbContext
{
    public ContactContext(DbContextOptions options) : base(options) { }
   public  DbSet<ContactTable> Contacts
    {
        get;
        set;
    }
}