﻿
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

namespace AspektWebAPIZadaca
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            var connectionString = Configuration.GetConnectionString("DefaultConnection");
            services.AddDbContext<CompanyContext>(options => options.UseSqlServer(connectionString));
            services.AddDbContext<ContactContext>(options => options.UseSqlServer(connectionString));
            services.AddDbContext<CountryContext>(options => options.UseSqlServer(connectionString));
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
